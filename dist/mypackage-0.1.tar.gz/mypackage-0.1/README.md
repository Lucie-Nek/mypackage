# mypackage
This library was created as an example of how to publish own Python package.

# How to install
...